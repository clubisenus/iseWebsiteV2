//dispatcher
export const TOGGLE_Navbar = text => ({
  type: 'TOGGLE_Navbar',
});