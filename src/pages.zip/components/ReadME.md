This is a section for all the components
- each page is a component
- each subsection is a component
    - eg sidebar