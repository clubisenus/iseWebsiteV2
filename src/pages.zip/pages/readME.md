This is for pages that can be directly accessed from domain/xyz
separate from subcomponents that can be reused in components