import { combineReducers } from 'redux'
import iseWebsite from './iseWebsite'

export default combineReducers({
  iseWebsite,
})
